import JacEditor from '../components/editor/JacEditor';

export default function EditorPage() {
  return <JacEditor />;
}
